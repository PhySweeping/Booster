# poboquant
quant strategy backtesting and live trading platform from pobo financial

visit https://quant.pobo.net.cn/quant/login#/

with invitation code 
814685 （No need for current version）
Options Tick Level Backtest supported.

Python Strategy Runs on Poboquant Platform， for both back test and live trading. 

API Doc is here https://quant.pobo.net.cn/quant/doc?name=api

More tips https://quant.pobo.net.cn/doc?name=tips

any issue, please post or contact me via qq 350052799

To connect Simnow account https://github.com/qmhedging/poboquant/wiki/%E4%BA%91%E9%87%8F%E5%8C%96-%E4%BD%BF%E7%94%A8%E6%8A%80%E5%B7%A7-Poboquant-Tips

澎博财经 量化策略研究与实盘交易平台 

欢迎访问 https://quant.pobo.net.cn/quant/login#/

Python策略代码可在Poboquant平台运行回测与实盘交易

注册时 使用 邀请码 814685 （正式版推出后已经不需要邀请码）

API文档可参见 https://quant.pobo.net.cn/quant/doc?name=api

更多的使用技巧 https://quant.pobo.net.cn/doc?name=tips

如果有问题，欢迎在git issues上吐槽 

也可以告诉我 qq 350052799，我帮你吐槽 

也欢迎加群qq 726895887 向工程师反映问题 

如何连接simnow账户 https://github.com/qmhedging/poboquant/wiki/%E4%BA%91%E9%87%8F%E5%8C%96-%E4%BD%BF%E7%94%A8%E6%8A%80%E5%B7%A7-Poboquant-Tips

期货策略回测界面 Futures Back Test UI：

![image](https://github.com/qmhedging/poboquant/blob/master/%E6%BE%8E%E5%8D%9A%E4%BA%91%E9%87%8F%E5%8C%96mag.jpg)

50ETF期权策略回测界面 China 50ETF Options Strategy Back Test UI：

![image](https://github.com/qmhedging/poboquant/blob/master/%E6%BE%8E%E5%8D%9A%E4%BA%91%E9%87%8F%E5%8C%96-%E6%9C%9F%E6%9D%83.jpg)

回测-查询期权历史交易流水
![image](https://github.com/qmhedging/poboquant/blob/master/poboquant.jpg)
